import { supabase } from '../lib/supabase';
import type { Database } from '../lib/supabase';
import { transactionService } from './transactionService';

type Appointment = Database['public']['Tables']['appointments']['Row'];
type AppointmentInsert = Omit<Appointment, 'id' | 'created_at'>;

export const appointmentService = {
    async getAll() {
        const { data, error } = await supabase
            .from('appointments')
            .select(`
        *,
        public_token,
        clients (
          name,
          phone,
          address
        )
      `)
            .order('scheduled_date', { ascending: true })
            .order('scheduled_time', { ascending: true });

        if (error) throw error;
        return data;
    },

    async getByDate(date: string) {
        const { data, error } = await supabase
            .from('appointments')
            .select(`
        *,
        public_token,
        clients (
          name,
          phone,
          address
        )
      `)
            .eq('scheduled_date', date)
            .order('scheduled_time', { ascending: true });

        if (error) throw error;
        return data;
    },

    async create(appointment: AppointmentInsert) {
        const { data, error } = await supabase
            .from('appointments')
            .insert(appointment)
            .select()
            .single();

        if (error) throw error;
        return data;
    },

    async update(id: string, updates: Partial<Appointment>) {
        const { data, error } = await supabase
            .from('appointments')
            .update(updates)
            .eq('id', id)
            .select()
            .single();

        if (error) throw error;

        // Automação Financeira: Se concluído, gera receita
        if (updates.status === 'completed' && data) {
            try {
                await transactionService.create({
                    type: 'income',
                    amount: data.price,
                    description: `Serviço: ${data.service_type}`,
                    category: 'serviço',
                    appointment_id: data.id,
                    user_id: data.user_id
                });
            } catch (err) {
                console.error('Erro na automação financeira:', err);
            }
        }

        return data;
    },

    async updateStatus(id: string, status: Appointment['status']) {
        return this.update(id, { status });
    },

    async delete(id: string) {
        const { error } = await supabase
            .from('appointments')
            .delete()
            .eq('id', id);

        if (error) throw error;
    }
};

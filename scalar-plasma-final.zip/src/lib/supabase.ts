import { createClient } from '@supabase/supabase-js';

// Para desenvolvimento local, usamos valores placeholder
// Em produção, estas variáveis virão do .env
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

if (!supabaseUrl || !supabaseAnonKey) {
    console.warn('Supabase: Faltam chaves de API. Backend rodando em modo limitado (ver .env.example)');
}

export const supabase = createClient(
    supabaseUrl || 'https://placeholder.supabase.co',
    supabaseAnonKey || 'placeholder-key'
);

// Types para o banco de dados
export interface Database {
    public: {
        Tables: {
            clients: {
                Row: {
                    id: string;
                    created_at: string;
                    name: string;
                    phone: string;
                    email: string | null;
                    address: string | null;
                    status: 'lead' | 'active' | 'inactive';
                    source: 'whatsapp' | 'instagram' | 'facebook' | 'manual';
                    user_id: string;
                };
                Insert: Omit<Database['public']['Tables']['clients']['Row'], 'id' | 'created_at'>;
            };
            appointments: {
                Row: {
                    id: string;
                    created_at: string;
                    client_id: string;
                    service_type: string;
                    scheduled_date: string;
                    scheduled_time: string;
                    status: 'scheduled' | 'in_progress' | 'completed' | 'cancelled';
                    address: string | null;
                    notes: string | null;
                    price: number;
                    user_id: string;
                    company_id?: string;
                    public_token?: string;
                };
            };
            transactions: {
                Row: {
                    id: string;
                    created_at: string;
                    type: 'income' | 'expense';
                    amount: number;
                    description: string;
                    category: string;
                    appointment_id: string | null;
                    user_id: string;
                };
            };
        };
    };
}

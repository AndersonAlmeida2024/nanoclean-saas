import { Home, Calendar, Users, DollarSign, Menu, LogOut } from 'lucide-react';
import { NavLink } from 'react-router-dom';
import { useState } from 'react';
import { cn } from '../utils/cn';
import { motion } from 'framer-motion';
import { useAuthStore } from '../stores/authStore';

const NAV_ITEMS = [
    { icon: Home, label: 'Dashboard', path: '/' },
    { icon: Calendar, label: 'Agenda', path: '/schedule' },
    { icon: Users, label: 'Clientes (CRM)', path: '/crm' },
    { icon: DollarSign, label: 'Financeiro', path: '/finance' },
];

export function Sidebar() {
    const [isCollapsed, setIsCollapsed] = useState(false);
    const logout = useAuthStore((state) => state.logout);

    return (
        <motion.aside
            initial={false}
            animate={{ width: isCollapsed ? '80px' : '280px' }}
            className="h-screen bg-black/40 backdrop-blur-xl border-r border-white/10 flex flex-col fixed left-0 top-0 z-50 transition-all duration-300"
        >
            {/* Header */}
            <div className="p-6 flex items-center justify-between">
                {!isCollapsed && (
                    <motion.div
                        initial={{ opacity: 0 }}
                        animate={{ opacity: 1 }}
                        className="font-bold text-2xl bg-gradient-to-r from-cyan-400 to-purple-500 bg-clip-text text-transparent"
                    >
                        NanoClean
                    </motion.div>
                )}
                <button
                    onClick={() => setIsCollapsed(!isCollapsed)}
                    className="p-2 hover:bg-white/5 rounded-lg text-gray-400 hover:text-white transition-colors"
                >
                    <Menu size={20} />
                </button>
            </div>

            {/* Navigation */}
            <nav className="flex-1 px-4 py-4 space-y-2">
                {NAV_ITEMS.map((item) => (
                    <NavLink
                        key={item.path}
                        to={item.path}
                        className={({ isActive }) => cn(
                            "flex items-center gap-4 px-4 py-3 rounded-xl transition-all duration-200 group relative overflow-hidden",
                            isActive
                                ? "bg-gradient-to-r from-cyan-500/20 to-purple-500/20 text-white shadow-[0_0_20px_rgba(6_182_212_0.15)] border border-white/5"
                                : "text-gray-400 hover:text-white hover:bg-white/5"
                        )}
                    >
                        {({ isActive }) => (
                            <>
                                <item.icon size={22} className={cn("shrink-0", isCollapsed && "mx-auto")} />

                                {!isCollapsed && (
                                    <span className="font-medium whitespace-nowrap">{item.label}</span>
                                )}

                                {/* Active Indicator Line */}
                                {isActive && !isCollapsed && (
                                    <motion.div
                                        layoutId="active-nav"
                                        className="absolute left-0 top-0 bottom-0 w-1 bg-gradient-to-b from-cyan-400 to-purple-500 rounded-r-full"
                                    />
                                )}
                            </>
                        )}
                    </NavLink>
                ))}
            </nav>

            {/* Footer */}
            <div className="p-4 border-t border-white/5">
                <button
                    onClick={logout}
                    className={cn(
                        "flex items-center gap-4 w-full px-4 py-3 text-gray-400 hover:text-red-400 hover:bg-red-500/10 rounded-xl transition-colors",
                        isCollapsed && "justify-center"
                    )}>
                    <LogOut size={20} />
                    {!isCollapsed && <span>Sair</span>}
                </button>
            </div>
        </motion.aside>
    );
}

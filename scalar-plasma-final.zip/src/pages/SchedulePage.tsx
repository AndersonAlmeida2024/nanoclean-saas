import { useState, useEffect, useCallback, useMemo } from 'react';
import {
    ChevronLeft,
    ChevronRight,
    Plus,
    Clock,
    User,
    MoreVertical,
    CheckCircle2,
    Loader2,
    AlertCircle,
    MapPin,
    ExternalLink,
    Edit2,
    XCircle,
    MessageCircle,
    Calendar
} from 'lucide-react';
import { cn } from '../utils/cn';
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth, isToday, isSameDay, addMonths, subMonths, parseISO } from 'date-fns';
import { ptBR } from 'date-fns/locale';
import { appointmentService } from '../services/appointmentService';
import { AppointmentModal } from '../modules/agenda/components/AppointmentModal';

export function SchedulePage() {
    const [currentMonth, setCurrentMonth] = useState(new Date());
    const [selectedDate, setSelectedDate] = useState(new Date());
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [editingAppointment, setEditingAppointment] = useState<any>(null);
    const [activeMenuId, setActiveMenuId] = useState<string | null>(null);
    const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);
    const [appointments, setAppointments] = useState<any[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const loadAppointments = useCallback(async () => {
        try {
            setIsLoading(true);
            const data = await appointmentService.getAll();
            setAppointments(data || []);
            setError(null);
        } catch (err) {
            console.error('Erro ao carregar agenda:', err);
            setError('Não foi possível carregar os agendamentos.');
        } finally {
            setIsLoading(false);
        }
    }, []);

    useEffect(() => {
        loadAppointments();
    }, [loadAppointments]);

    const monthStart = startOfMonth(currentMonth);
    const monthEnd = endOfMonth(currentMonth);
    const days = eachDayOfInterval({ start: monthStart, end: monthEnd });

    const appointmentsForSelectedDate = useMemo(() => {
        return appointments.filter(apt =>
            isSameDay(parseISO(apt.scheduled_date), selectedDate)
        );
    }, [appointments, selectedDate]);

    const getAppointmentsForDay = (day: Date) => {
        return appointments.filter(apt => isSameDay(parseISO(apt.scheduled_date), day));
    };

    const handleUpdateStatus = async (id: string, status: any) => {
        try {
            setIsLoading(true);
            await appointmentService.updateStatus(id, status);
            await loadAppointments();
        } catch (err: any) {
            console.error('Erro ao atualizar status:', err);
            alert(`Erro do Banco (Status): ${err.message || 'Erro desconhecido'}`);
        } finally {
            setIsLoading(false);
        }
    };

    const handleConfirmCancel = async (id: string) => {
        try {
            setIsLoading(true);
            await appointmentService.updateStatus(id, 'cancelled');
            await loadAppointments();
            setDeleteConfirmId(null);
            setActiveMenuId(null);
        } catch (err: any) {
            console.error('Erro ao cancelar agendamento:', err);
            alert(`Erro do Banco (Cancelamento): ${err.message || 'O banco recusou a alteração.'}`);
        } finally {
            setIsLoading(false);
        }
    };

    const handleEdit = (apt: any) => {
        setEditingAppointment(apt);
        setIsModalOpen(true);
        setActiveMenuId(null);
    };

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-3xl font-bold bg-gradient-to-r from-white to-gray-400 bg-clip-text text-transparent">
                        Agenda
                    </h1>
                    <p className="text-gray-400 mt-1">Gerencie seus agendamentos e serviços.</p>
                </div>

                <button
                    onClick={() => {
                        setEditingAppointment(null);
                        setIsModalOpen(true);
                    }}
                    className="flex items-center gap-2 bg-gradient-to-r from-cyan-600 to-cyan-500 hover:from-cyan-500 hover:to-cyan-400 text-white px-6 py-2.5 rounded-xl font-medium transition-all shadow-lg shadow-cyan-900/20"
                >
                    <Plus size={20} />
                    Novo Agendamento
                </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Calendar */}
                <div className="lg:col-span-2 bg-white/5 border border-white/10 rounded-2xl p-6 relative">
                    {isLoading && (
                        <div className="absolute inset-0 z-10 bg-black/20 backdrop-blur-[1px] flex items-center justify-center rounded-2xl">
                            <Loader2 className="animate-spin text-cyan-500" size={32} />
                        </div>
                    )}

                    {/* Month Navigation */}
                    <div className="flex items-center justify-between mb-6">
                        <h2 className="text-xl font-semibold text-white capitalize">
                            {format(currentMonth, 'MMMM yyyy', { locale: ptBR })}
                        </h2>
                        <div className="flex gap-2">
                            <button
                                onClick={() => setCurrentMonth(subMonths(currentMonth, 1))}
                                className="p-2 hover:bg-white/10 rounded-lg transition-colors"
                            >
                                <ChevronLeft size={20} className="text-gray-400" />
                            </button>
                            <button
                                onClick={() => setCurrentMonth(new Date())}
                                className="px-3 py-1 text-sm bg-white/10 rounded-lg hover:bg-white/20 transition-colors"
                            >
                                Hoje
                            </button>
                            <button
                                onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}
                                className="p-2 hover:bg-white/10 rounded-lg transition-colors"
                            >
                                <ChevronRight size={20} className="text-gray-400" />
                            </button>
                        </div>
                    </div>

                    {error && (
                        <div className="mb-6 p-4 bg-red-500/10 border border-red-500/20 rounded-xl flex items-center gap-3 text-red-400 text-sm">
                            <AlertCircle size={18} />
                            {error}
                        </div>
                    )}

                    {/* Day Headers */}
                    <div className="grid grid-cols-7 gap-2 mb-2">
                        {['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'].map(day => (
                            <div key={day} className="text-center text-sm text-zinc-500 py-2">
                                {day}
                            </div>
                        ))}
                    </div>

                    {/* Calendar Grid */}
                    <div className="grid grid-cols-7 gap-2">
                        {Array.from({ length: monthStart.getDay() }).map((_, i) => (
                            <div key={`empty - ${i} `} className="aspect-square" />
                        ))}

                        {days.map(day => {
                            const dayAppointments = getAppointmentsForDay(day);
                            const isSelected = isSameDay(day, selectedDate);

                            return (
                                <button
                                    key={day.toISOString()}
                                    onClick={() => setSelectedDate(day)}
                                    className={cn(
                                        "aspect-square rounded-xl flex flex-col items-center justify-center transition-all relative",
                                        isToday(day) && !isSelected && "ring-2 ring-cyan-500/50",
                                        isSelected && "bg-cyan-500 text-white shadow-lg shadow-cyan-900/40",
                                        !isSelected && "hover:bg-white/5",
                                        !isSameMonth(day, currentMonth) && "opacity-30"
                                    )}
                                >
                                    <span className={cn(
                                        "text-sm font-medium",
                                        !isSelected && "text-zinc-300"
                                    )}>
                                        {format(day, 'd')}
                                    </span>
                                    {dayAppointments.length > 0 && (
                                        <div className="absolute bottom-1.5 flex gap-0.5">
                                            {dayAppointments.slice(0, 3).map((apt, i) => (
                                                <div
                                                    key={i}
                                                    className={cn(
                                                        "w-1.5 h-1.5 rounded-full",
                                                        isSelected ? "bg-white" :
                                                            apt.status === 'completed' ? "bg-green-400" :
                                                                apt.status === 'in_progress' ? "bg-cyan-400" :
                                                                    apt.status === 'cancelled' ? "bg-red-500" : "bg-purple-400"
                                                    )}
                                                />
                                            ))}
                                        </div>
                                    )}
                                </button>
                            );
                        })}
                    </div>
                </div>

                {/* Day Detail */}
                <div className="bg-white/5 border border-white/10 rounded-2xl p-6">
                    <div className="flex items-center justify-between mb-6">
                        <h3 className="text-lg font-semibold text-white">
                            {format(selectedDate, "d 'de' MMMM", { locale: ptBR })}
                        </h3>
                        <span className="text-xs text-zinc-500 uppercase tracking-wider font-bold">
                            {appointmentsForSelectedDate.length} {appointmentsForSelectedDate.length === 1 ? 'Serviço' : 'Serviços'}
                        </span>
                    </div>

                    {appointmentsForSelectedDate.length === 0 ? (
                        <div className="text-center py-12 text-zinc-600">
                            <Clock size={40} className="mx-auto mb-4 opacity-20" />
                            <p className="text-sm">Nenhum agendamento para hoje.</p>
                            <button
                                onClick={() => {
                                    setEditingAppointment(null);
                                    setIsModalOpen(true);
                                }}
                                className="mt-4 text-cyan-400 text-xs hover:text-cyan-300 font-bold uppercase tracking-widest"
                            >
                                + Agendar agora
                            </button>
                        </div>
                    ) : (
                        <div className="space-y-4">
                            {appointmentsForSelectedDate.map(apt => (
                                <div
                                    key={apt.id}
                                    className={cn(
                                        "p-4 rounded-xl border transition-all group relative",
                                        apt.status === 'completed' ? "bg-green-500/5 border-green-500/10" :
                                            apt.status === 'in_progress' ? "bg-cyan-500/10 border-cyan-500/20" :
                                                apt.status === 'cancelled' ? "bg-red-500/5 border-red-500/10 opacity-60" :
                                                    "bg-white/[0.03] border-white/5"
                                    )}
                                >
                                    <div className="flex items-start justify-between mb-3">
                                        <span className={cn(
                                            "text-lg font-black tracking-tight",
                                            apt.status === 'in_progress' ? "text-cyan-400" :
                                                apt.status === 'completed' ? "text-green-400" :
                                                    apt.status === 'cancelled' ? "text-red-400" : "text-white/40"
                                        )}>
                                            {apt.scheduled_time}
                                        </span>
                                        <div className="flex items-center gap-1">
                                            <div className="flex gap-1 transition-all mr-2">
                                                {/* WhatsApp + Auto Agenda Link */}
                                                <button
                                                    onClick={(e) => {
                                                        e.stopPropagation();
                                                        if (!apt.clients?.phone) {
                                                            alert('Cliente sem telefone cadastrado.');
                                                            return;
                                                        }
                                                        const shareUrl = `${window.location.origin}/share/${apt.public_token}`;
                                                        const message = `Olá ${apt.clients.name}! Confirmamos seu serviço para ${format(parseISO(apt.scheduled_date), 'dd/MM')} às ${apt.scheduled_time}.\n\nPara não esquecer, adicione à sua agenda clicando aqui: ${shareUrl}`;

                                                        window.open(`https://wa.me/${apt.clients.phone.replace(/\D/g, '')}?text=${encodeURIComponent(message)}`, '_blank');
                                                    }}
                                                    className="p-1.5 bg-green-500/10 hover:bg-green-500/20 text-green-500 rounded-lg transition-colors border border-green-500/20"
                                                    title="Confirmar via WhatsApp"
                                                >
                                                    <MessageCircle size={14} />
                                                </button>

                                                {/* Iniciar Serviço */}
                                                {apt.status === 'scheduled' && (
                                                    <button
                                                        onClick={(e) => { e.stopPropagation(); handleUpdateStatus(apt.id, 'in_progress'); }}
                                                        className="p-1.5 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400 rounded-lg transition-colors border border-cyan-500/20"
                                                        title="Iniciar Serviço"
                                                    >
                                                        <Clock size={14} />
                                                    </button>
                                                )}

                                                {/* Concluir Serviço */}
                                                {apt.status !== 'completed' && apt.status !== 'cancelled' && (
                                                    <button
                                                        onClick={(e) => { e.stopPropagation(); handleUpdateStatus(apt.id, 'completed'); }}
                                                        className="p-1.5 bg-green-500/10 hover:bg-green-500/20 text-green-400 rounded-lg transition-colors border border-green-500/20"
                                                        title="Concluir"
                                                    >
                                                        <CheckCircle2 size={14} />
                                                    </button>
                                                )}
                                            </div>

                                            <div className="relative">
                                                <button
                                                    onClick={(e) => { e.stopPropagation(); setActiveMenuId(activeMenuId === apt.id ? null : apt.id); }}
                                                    className={cn(
                                                        "p-1.5 rounded-lg transition-colors",
                                                        activeMenuId === apt.id ? "bg-white/10 text-white" : "hover:bg-white/10 text-zinc-500"
                                                    )}
                                                >
                                                    <MoreVertical size={16} />
                                                </button>

                                                {activeMenuId === apt.id && (
                                                    <>
                                                        <div
                                                            className="fixed inset-0 z-20"
                                                            onClick={() => setActiveMenuId(null)}
                                                        />
                                                        <div className="absolute right-0 mt-2 w-48 bg-[#1a1a1a] border border-white/10 rounded-xl shadow-2xl z-30 overflow-hidden animate-in fade-in zoom-in duration-200">
                                                            {apt.status === 'cancelled' ? (
                                                                <button
                                                                    onClick={() => {
                                                                        handleUpdateStatus(apt.id, 'scheduled');
                                                                        setActiveMenuId(null);
                                                                    }}
                                                                    className="w-full flex items-center gap-2 px-4 py-4 text-sm text-green-400 hover:bg-green-500/10 transition-colors"
                                                                >
                                                                    <CheckCircle2 size={14} />
                                                                    Reativar Agendamento
                                                                </button>
                                                            ) : (
                                                                <>
                                                                    <button
                                                                        onClick={() => handleEdit(apt)}
                                                                        className="w-full flex items-center gap-2 px-4 py-3 text-sm text-gray-300 hover:bg-white/5 hover:text-white transition-colors"
                                                                    >
                                                                        <Edit2 size={14} className="text-cyan-400" />
                                                                        Editar Agendamento
                                                                    </button>

                                                                    {deleteConfirmId === apt.id ? (
                                                                        <div className="p-2 bg-red-500/10 border-t border-white/5">
                                                                            <p className="text-[10px] text-red-400 text-center mb-2 font-bold uppercase">Confirmar Cancelamento?</p>
                                                                            <div className="flex gap-2">
                                                                                <button
                                                                                    onClick={() => handleConfirmCancel(apt.id)}
                                                                                    className="flex-1 py-1.5 bg-red-500 text-white text-[10px] font-black rounded-lg hover:bg-red-600 transition-colors"
                                                                                >
                                                                                    SIM
                                                                                </button>
                                                                                <button
                                                                                    onClick={() => setDeleteConfirmId(null)}
                                                                                    className="flex-1 py-1.5 bg-white/10 text-white text-[10px] font-black rounded-lg hover:bg-white/20 transition-colors"
                                                                                >
                                                                                    NÃO
                                                                                </button>
                                                                            </div>
                                                                        </div>
                                                                    ) : (
                                                                        <button
                                                                            onClick={() => setDeleteConfirmId(apt.id)}
                                                                            className="w-full flex items-center gap-2 px-4 py-3 text-sm text-red-400 hover:bg-red-500/10 transition-colors border-t border-white/5"
                                                                        >
                                                                            <XCircle size={14} />
                                                                            Cancelar Agendamento
                                                                        </button>
                                                                    )}
                                                                </>
                                                            )}
                                                        </div>
                                                    </>
                                                )}
                                            </div>
                                        </div>
                                    </div>

                                    <p className="font-bold text-white mb-1">{apt.service_type}</p>

                                    <div className="flex flex-col gap-1.5 mb-4">
                                        <div className="flex items-center gap-2 text-xs text-zinc-400">
                                            <User size={12} className="text-zinc-600" />
                                            <span>{apt.clients?.name || 'Cliente removido'}</span>
                                        </div>
                                        {(() => {
                                            const serviceAddress = apt.address || apt.clients?.address;
                                            if (!serviceAddress) return null;
                                            return (
                                                <div className="flex items-center gap-2 text-[11px] text-zinc-500">
                                                    <MapPin size={12} className="text-zinc-700" />
                                                    <span className="truncate flex-1">{serviceAddress}</span>
                                                    <a
                                                        href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(serviceAddress)}`}
                                                        target="_blank"
                                                        rel="noopener noreferrer"
                                                        className="flex items-center gap-1 text-cyan-500 hover:text-cyan-400 font-bold ml-1 transition-colors"
                                                    >
                                                        GPS <ExternalLink size={10} />
                                                    </a>
                                                </div>
                                            );
                                        })()}
                                    </div>

                                    <div className="flex items-center justify-between pt-3 border-t border-white/5">
                                        <span className="text-green-400 font-bold text-sm">
                                            R$ {Number(apt.price).toLocaleString('pt-BR', { minimumFractionDigits: 2 })}
                                        </span>

                                        {apt.status === 'completed' && (
                                            <span className="text-[10px] font-black uppercase tracking-widest bg-green-500/20 text-green-400 px-2 py-1 rounded-md">
                                                Concluído
                                            </span>
                                        )}

                                        {apt.status === 'in_progress' && (
                                            <span className="text-[10px] font-black uppercase tracking-widest bg-cyan-500/20 text-cyan-400 px-2 py-1 rounded-md animate-pulse">
                                                Em Execução
                                            </span>
                                        )}

                                        {apt.status === 'scheduled' && (
                                            <span className="text-[10px] font-black uppercase tracking-widest bg-white/5 text-zinc-500 px-2 py-1 rounded-md">
                                                Agendado
                                            </span>
                                        )}

                                        {apt.status === 'cancelled' && (
                                            <span className="text-[10px] font-black uppercase tracking-widest bg-red-500/20 text-red-400 px-2 py-1 rounded-md">
                                                Cancelado
                                            </span>
                                        )}
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            </div>

            <AppointmentModal
                isOpen={isModalOpen}
                onClose={() => {
                    setIsModalOpen(false);
                    setEditingAppointment(null);
                }}
                onSuccess={loadAppointments}
                selectedDate={selectedDate}
                appointment={editingAppointment}
            />
        </div>
    );
}

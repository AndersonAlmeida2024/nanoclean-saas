// arquivo: src/stores/authStore.ts
import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { User } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';
import { userService } from '../services/userService';

// Definição estrita do estado de Auth (ARCH)
interface AuthState {
    user: User | null;
    companyId: string | null;
    isLoading: boolean;
    isAuthenticated: boolean;
    initialize: () => Promise<void>;
    logout: () => Promise<void>;
    _setSession: (user: User | null, companyId: string | null) => void;
}

export const useAuthStore = create<AuthState>()(
    persist(
        (set) => ({
            user: null,
            companyId: null,
            isLoading: true,
            isAuthenticated: false,

            _setSession: (user, companyId) => set({
                user,
                companyId,
                isAuthenticated: !!user,
                isLoading: false
            }),

            logout: async () => {
                await supabase.auth.signOut();
                set({ user: null, companyId: null, isAuthenticated: false, isLoading: false });
                localStorage.removeItem('nanoclean_auth');
            },

            initialize: async () => {
                set({ isLoading: true });
                try {
                    const { data: { session } } = await supabase.auth.getSession();

                    if (session?.user) {
                        const profile = await userService.getProfile(session.user.id);
                        set({
                            user: session.user,
                            companyId: profile?.company_id || null,
                            isAuthenticated: true
                        });
                    } else {
                        set({ user: null, companyId: null, isAuthenticated: false });
                    }

                    // Real-time Auth Listening (SEC)
                    supabase.auth.onAuthStateChange(async (event, session) => {
                        if (event === 'SIGNED_IN' && session?.user) {
                            const profile = await userService.getProfile(session.user.id);
                            set({ user: session.user, companyId: profile?.company_id || null, isAuthenticated: true });
                        } else if (event === 'SIGNED_OUT') {
                            set({ user: null, companyId: null, isAuthenticated: false });
                        }
                    });
                } finally {
                    set({ isLoading: false });
                }
            }
        }),
        {
            name: 'nanoclean_auth',
            partialize: (state) => ({
                user: state.user,
                companyId: state.companyId,
                isAuthenticated: state.isAuthenticated
            }),
        }
    )
);
